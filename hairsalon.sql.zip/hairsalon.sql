--
-- Database: `hairsalon`
--
CREATE DATABASE IF NOT EXISTS `hairsalon` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `hairsalon`;

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `name`, `client_id`) VALUES
(1, 'Sarah', 27),
(2, 'Sarah', 29),
(3, 'Emily', 31),
(4, 'Emily', 31),
(5, 'Sarah', 31),
(6, 'Emily', 31),
(7, 'Autumn', 31),
(8, 'Polina', 31),
(9, 'Jackie', 31),
(10, 'Autumn', 32),
(11, 'Autumn', 32),
(12, 'Autumn', 32),
(13, 'Polina', 32),
(14, 'Emily', 32),
(15, 'Jackie', 32),
(16, 'Jackie', 32),
(17, 'Sarah', 32),
(18, 'Polina', 32),
(19, 'Polina', 32),
(20, 'Polina', 32),
(21, 'Polina', 32),
(22, 'Polina', 32),
(23, 'Polina', 33),
(24, 'Autumn', 33),
(25, 'Polina', 33),
(26, 'Sarah', 33),
(27, 'Sarah', 33),
(28, 'Sarah', 33),
(29, 'Autumn', 34),
(30, 'Jenn', 34),
(31, 'Sarah', 38),
(32, 'Sarah', 38),
(33, 'Autumn', 38),
(34, 'Polina', 38),
(35, 'Jackie', 39),
(36, 'Autumn', 39),
(37, 'Jenn', 39),
(38, 'Sarah', 40),
(39, 'Emily', 41),
(40, 'Polina', 41),
(41, 'Sarah', 42),
(42, 'Sarah', 42),
(43, 'Emily', 43),
(44, '', 44),
(45, 'Jessica', 45),
(46, 'Autumn', 52),
(47, 'Polina', 52),
(48, 'Jackie', 52),
(49, 'Sarah', 53),
(50, 'Polina', 53),
(51, 'Joelette', 54),
(52, 'Summer', 52),
(53, '', 55),
(54, 'Jessica', 56),
(55, 'Sarah', 57),
(56, 'Jeff', 61),
(57, 'Autumn', 69),
(58, 'Jackie', 69),
(59, 'Jenn', 70),
(60, 'Brianna', 71),
(61, 'Brianna', 69),
(62, 'Ciara', 74),
(63, 'Polina', 74),
(64, 'Emily', 74),
(65, 'Autumn', 75),
(66, 'Jackie', 75),
(67, 'Jenn', 75),
(68, 'Sarah', 74),
(75, 'Polina', 78),
(80, 'Jenn', 82),
(85, 'Sarah', 81);

-- --------------------------------------------------------

--
-- Table structure for table `stylists`
--

CREATE TABLE `stylists` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stylists`
--

INSERT INTO `stylists` (`id`, `name`) VALUES
(83, 'Brianna');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stylists`
--
ALTER TABLE `stylists`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;
--
-- AUTO_INCREMENT for table `stylists`
--
ALTER TABLE `stylists`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
